var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "21600",
        "ok": "21600",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "8495",
        "ok": "8495",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3224",
        "ok": "3224",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "2143",
        "ok": "2143",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3306",
        "ok": "3306",
        "ko": "-"
    },
    "percentiles2": {
        "total": "4925",
        "ok": "4925",
        "ko": "-"
    },
    "percentiles3": {
        "total": "6678",
        "ok": "6678",
        "ko": "-"
    },
    "percentiles4": {
        "total": "7643",
        "ok": "7643",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 4116,
    "percentage": 19
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 953,
    "percentage": 4
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 16531,
    "percentage": 77
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "459.574",
        "ok": "459.574",
        "ko": "-"
    }
},
contents: {
"req_insert-player-r-6c82f": {
        type: "REQUEST",
        name: "Insert player ranks",
path: "Insert player ranks",
pathFormatted: "req_insert-player-r-6c82f",
stats: {
    "name": "Insert player ranks",
    "numberOfRequests": {
        "total": "1000",
        "ok": "1000",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "175",
        "ok": "175",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "26",
        "ok": "26",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "26",
        "ok": "26",
        "ko": "-"
    },
    "percentiles1": {
        "total": "14",
        "ok": "14",
        "ko": "-"
    },
    "percentiles2": {
        "total": "30",
        "ok": "30",
        "ko": "-"
    },
    "percentiles3": {
        "total": "81",
        "ok": "81",
        "ko": "-"
    },
    "percentiles4": {
        "total": "139",
        "ok": "139",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1000,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "21.277",
        "ok": "21.277",
        "ko": "-"
    }
}
    },"req_get-player-rank-90846": {
        type: "REQUEST",
        name: "Get player ranks",
path: "Get player ranks",
pathFormatted: "req_get-player-rank-90846",
stats: {
    "name": "Get player ranks",
    "numberOfRequests": {
        "total": "20500",
        "ok": "20500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "8495",
        "ok": "8495",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3380",
        "ok": "3380",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "2071",
        "ok": "2071",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3450",
        "ok": "3451",
        "ko": "-"
    },
    "percentiles2": {
        "total": "4979",
        "ok": "4979",
        "ko": "-"
    },
    "percentiles3": {
        "total": "6731",
        "ok": "6731",
        "ko": "-"
    },
    "percentiles4": {
        "total": "7658",
        "ok": "7658",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 3094,
    "percentage": 15
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 951,
    "percentage": 5
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 16455,
    "percentage": 80
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "436.17",
        "ok": "436.17",
        "ko": "-"
    }
}
    },"req_update-scores-221b9": {
        type: "REQUEST",
        name: "Update scores",
path: "Update scores",
pathFormatted: "req_update-scores-221b9",
stats: {
    "name": "Update scores",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "8182",
        "ok": "8182",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3248",
        "ok": "3248",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "2351",
        "ok": "2351",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3246",
        "ok": "3246",
        "ko": "-"
    },
    "percentiles2": {
        "total": "5033",
        "ok": "5033",
        "ko": "-"
    },
    "percentiles3": {
        "total": "7468",
        "ok": "7468",
        "ko": "-"
    },
    "percentiles4": {
        "total": "7749",
        "ok": "7749",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 22,
    "percentage": 22
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 2,
    "percentage": 2
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 76,
    "percentage": 76
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "2.128",
        "ok": "2.128",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
