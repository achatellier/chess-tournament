var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "40900",
        "ok": "40900",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "5182",
        "ok": "5182",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1460",
        "ok": "1460",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1208",
        "ok": "1208",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1423",
        "ok": "1424",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2439",
        "ok": "2439",
        "ko": "-"
    },
    "percentiles3": {
        "total": "3486",
        "ok": "3486",
        "ko": "-"
    },
    "percentiles4": {
        "total": "4198",
        "ok": "4198",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 15858,
    "percentage": 39
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 2922,
    "percentage": 7
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 22120,
    "percentage": 54
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "951.163",
        "ok": "951.163",
        "ko": "-"
    }
},
contents: {
"req_insert-player-r-6c82f": {
        type: "REQUEST",
        name: "Insert player ranks",
path: "Insert player ranks",
pathFormatted: "req_insert-player-r-6c82f",
stats: {
    "name": "Insert player ranks",
    "numberOfRequests": {
        "total": "300",
        "ok": "300",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "4",
        "ok": "4",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "248",
        "ok": "248",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "14",
        "ok": "14",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "33",
        "ok": "33",
        "ko": "-"
    },
    "percentiles1": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    },
    "percentiles2": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "percentiles3": {
        "total": "77",
        "ok": "77",
        "ko": "-"
    },
    "percentiles4": {
        "total": "180",
        "ok": "180",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 300,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "6.977",
        "ok": "6.977",
        "ko": "-"
    }
}
    },"req_get-player-rank-90846": {
        type: "REQUEST",
        name: "Get player ranks",
path: "Get player ranks",
pathFormatted: "req_get-player-rank-90846",
stats: {
    "name": "Get player ranks",
    "numberOfRequests": {
        "total": "40500",
        "ok": "40500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "5182",
        "ok": "5182",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1471",
        "ok": "1471",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1205",
        "ok": "1205",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1441",
        "ok": "1441",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2445",
        "ok": "2445",
        "ko": "-"
    },
    "percentiles3": {
        "total": "3488",
        "ok": "3488",
        "ko": "-"
    },
    "percentiles4": {
        "total": "4199",
        "ok": "4199",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 15510,
    "percentage": 38
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 2913,
    "percentage": 7
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 22077,
    "percentage": 55
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "941.86",
        "ok": "941.86",
        "ko": "-"
    }
}
    },"req_update-scores-221b9": {
        type: "REQUEST",
        name: "Update scores",
path: "Update scores",
pathFormatted: "req_update-scores-221b9",
stats: {
    "name": "Update scores",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "7",
        "ok": "7",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "4427",
        "ok": "4427",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1361",
        "ok": "1361",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1304",
        "ok": "1304",
        "ko": "-"
    },
    "percentiles1": {
        "total": "822",
        "ok": "822",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2576",
        "ok": "2576",
        "ko": "-"
    },
    "percentiles3": {
        "total": "3640",
        "ok": "3640",
        "ko": "-"
    },
    "percentiles4": {
        "total": "4327",
        "ok": "4327",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 48,
    "percentage": 48
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 9,
    "percentage": 9
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 43,
    "percentage": 43
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "2.326",
        "ok": "2.326",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
