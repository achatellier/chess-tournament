var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "51020",
        "ok": "51020",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "4101",
        "ok": "4101",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1560",
        "ok": "1560",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "911",
        "ok": "911",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1542",
        "ok": "1542",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2298",
        "ok": "2298",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2969",
        "ok": "2969",
        "ko": "-"
    },
    "percentiles4": {
        "total": "3602",
        "ok": "3601",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 10722,
    "percentage": 21
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 7008,
    "percentage": 14
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 33290,
    "percentage": 65
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1308.205",
        "ok": "1308.205",
        "ko": "-"
    }
},
contents: {
"req_insert-player-r-6c82f": {
        type: "REQUEST",
        name: "Insert player ranks",
path: "Insert player ranks",
pathFormatted: "req_insert-player-r-6c82f",
stats: {
    "name": "Insert player ranks",
    "numberOfRequests": {
        "total": "300",
        "ok": "300",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "375",
        "ok": "375",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "26",
        "ok": "26",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "58",
        "ok": "58",
        "ko": "-"
    },
    "percentiles1": {
        "total": "7",
        "ok": "7",
        "ko": "-"
    },
    "percentiles2": {
        "total": "8",
        "ok": "8",
        "ko": "-"
    },
    "percentiles3": {
        "total": "161",
        "ok": "161",
        "ko": "-"
    },
    "percentiles4": {
        "total": "260",
        "ok": "260",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 300,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "7.692",
        "ok": "7.692",
        "ko": "-"
    }
}
    },"req_get-player-rank-90846": {
        type: "REQUEST",
        name: "Get player ranks",
path: "Get player ranks",
pathFormatted: "req_get-player-rank-90846",
stats: {
    "name": "Get player ranks",
    "numberOfRequests": {
        "total": "50500",
        "ok": "50500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "4101",
        "ok": "4101",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1569",
        "ok": "1569",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "906",
        "ok": "906",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1549",
        "ok": "1549",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2303",
        "ok": "2304",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2969",
        "ok": "2969",
        "ko": "-"
    },
    "percentiles4": {
        "total": "3602",
        "ok": "3604",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 10375,
    "percentage": 21
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 6981,
    "percentage": 14
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 33144,
    "percentage": 66
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1294.872",
        "ok": "1294.872",
        "ko": "-"
    }
}
    },"req_update-scores-221b9": {
        type: "REQUEST",
        name: "Update scores",
path: "Update scores",
pathFormatted: "req_update-scores-221b9",
stats: {
    "name": "Update scores",
    "numberOfRequests": {
        "total": "220",
        "ok": "220",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "7",
        "ok": "7",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3932",
        "ok": "3932",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1593",
        "ok": "1593",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "938",
        "ok": "938",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1583",
        "ok": "1583",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2306",
        "ok": "2306",
        "ko": "-"
    },
    "percentiles3": {
        "total": "3061",
        "ok": "3061",
        "ko": "-"
    },
    "percentiles4": {
        "total": "3623",
        "ok": "3623",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 47,
    "percentage": 21
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 27,
    "percentage": 12
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 146,
    "percentage": 66
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5.641",
        "ok": "5.641",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
