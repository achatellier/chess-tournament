var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "6720",
        "ok": "6720",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2618",
        "ok": "2618",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "140",
        "ok": "140",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "378",
        "ok": "378",
        "ko": "-"
    },
    "percentiles1": {
        "total": "4",
        "ok": "4",
        "ko": "-"
    },
    "percentiles2": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1114",
        "ok": "1114",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1756",
        "ok": "1756",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 6238,
    "percentage": 93
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 188,
    "percentage": 3
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 294,
    "percentage": 4
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "181.622",
        "ok": "181.622",
        "ko": "-"
    }
},
contents: {
"req_insert-player-r-6c82f": {
        type: "REQUEST",
        name: "Insert player ranks",
path: "Insert player ranks",
pathFormatted: "req_insert-player-r-6c82f",
stats: {
    "name": "Insert player ranks",
    "numberOfRequests": {
        "total": "1000",
        "ok": "1000",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "114",
        "ok": "114",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2618",
        "ok": "2618",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "907",
        "ok": "907",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "517",
        "ok": "517",
        "ko": "-"
    },
    "percentiles1": {
        "total": "772",
        "ok": "772",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1298",
        "ok": "1298",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1811",
        "ok": "1811",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2134",
        "ok": "2134",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 518,
    "percentage": 52
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 188,
    "percentage": 19
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 294,
    "percentage": 29
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "27.027",
        "ok": "27.027",
        "ko": "-"
    }
}
    },"req_get-player-rank-90846": {
        type: "REQUEST",
        name: "Get player ranks",
path: "Get player ranks",
pathFormatted: "req_get-player-rank-90846",
stats: {
    "name": "Get player ranks",
    "numberOfRequests": {
        "total": "5500",
        "ok": "5500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "130",
        "ok": "130",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "11",
        "ok": "11",
        "ko": "-"
    },
    "percentiles1": {
        "total": "4",
        "ok": "4",
        "ko": "-"
    },
    "percentiles2": {
        "total": "4",
        "ok": "4",
        "ko": "-"
    },
    "percentiles3": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "percentiles4": {
        "total": "82",
        "ok": "82",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 5500,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "148.649",
        "ok": "148.649",
        "ko": "-"
    }
}
    },"req_update-scores-221b9": {
        type: "REQUEST",
        name: "Update scores",
path: "Update scores",
pathFormatted: "req_update-scores-221b9",
stats: {
    "name": "Update scores",
    "numberOfRequests": {
        "total": "220",
        "ok": "220",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "4",
        "ok": "4",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "126",
        "ok": "126",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "12",
        "ok": "12",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "22",
        "ok": "22",
        "ko": "-"
    },
    "percentiles1": {
        "total": "7",
        "ok": "7",
        "ko": "-"
    },
    "percentiles2": {
        "total": "8",
        "ok": "8",
        "ko": "-"
    },
    "percentiles3": {
        "total": "16",
        "ok": "16",
        "ko": "-"
    },
    "percentiles4": {
        "total": "119",
        "ok": "119",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 220,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5.946",
        "ok": "5.946",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
