var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "51600",
        "ok": "51019",
        "ko": "581"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "2094"
    },
    "maxResponseTime": {
        "total": "11454",
        "ok": "11454",
        "ko": "4713"
    },
    "meanResponseTime": {
        "total": "2154",
        "ok": "2149",
        "ko": "2545"
    },
    "standardDeviation": {
        "total": "1650",
        "ok": "1659",
        "ko": "223"
    },
    "percentiles1": {
        "total": "1842",
        "ok": "1829",
        "ko": "2524"
    },
    "percentiles2": {
        "total": "2710",
        "ok": "2717",
        "ko": "2658"
    },
    "percentiles3": {
        "total": "5421",
        "ok": "5431",
        "ko": "2835"
    },
    "percentiles4": {
        "total": "8141",
        "ok": "8160",
        "ko": "3064"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 9667,
    "percentage": 19
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 5586,
    "percentage": 11
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 35766,
    "percentage": 69
},
    "group4": {
    "name": "failed",
    "count": 581,
    "percentage": 1
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1146.667",
        "ok": "1133.756",
        "ko": "12.911"
    }
},
contents: {
"req_insert-player-r-6c82f": {
        type: "REQUEST",
        name: "Insert player ranks",
path: "Insert player ranks",
pathFormatted: "req_insert-player-r-6c82f",
stats: {
    "name": "Insert player ranks",
    "numberOfRequests": {
        "total": "1000",
        "ok": "1000",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "69",
        "ok": "69",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1500",
        "ok": "1500",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "526",
        "ok": "526",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "353",
        "ok": "353",
        "ko": "-"
    },
    "percentiles1": {
        "total": "390",
        "ok": "390",
        "ko": "-"
    },
    "percentiles2": {
        "total": "826",
        "ok": "826",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1182",
        "ok": "1182",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1315",
        "ok": "1315",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 740,
    "percentage": 74
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 219,
    "percentage": 22
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 41,
    "percentage": 4
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "22.222",
        "ok": "22.222",
        "ko": "-"
    }
}
    },"req_get-player-rank-90846": {
        type: "REQUEST",
        name: "Get player ranks",
path: "Get player ranks",
pathFormatted: "req_get-player-rank-90846",
stats: {
    "name": "Get player ranks",
    "numberOfRequests": {
        "total": "50500",
        "ok": "49923",
        "ko": "577"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "2094"
    },
    "maxResponseTime": {
        "total": "11454",
        "ok": "11454",
        "ko": "4713"
    },
    "meanResponseTime": {
        "total": "2186",
        "ok": "2182",
        "ko": "2544"
    },
    "standardDeviation": {
        "total": "1649",
        "ok": "1658",
        "ko": "221"
    },
    "percentiles1": {
        "total": "1867",
        "ok": "1853",
        "ko": "2523"
    },
    "percentiles2": {
        "total": "2745",
        "ok": "2756",
        "ko": "2656"
    },
    "percentiles3": {
        "total": "5438",
        "ok": "5454",
        "ko": "2833"
    },
    "percentiles4": {
        "total": "8172",
        "ok": "8187",
        "ko": "3069"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 8903,
    "percentage": 18
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 5354,
    "percentage": 11
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 35666,
    "percentage": 71
},
    "group4": {
    "name": "failed",
    "count": 577,
    "percentage": 1
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1122.222",
        "ok": "1109.4",
        "ko": "12.822"
    }
}
    },"req_update-scores-221b9": {
        type: "REQUEST",
        name: "Update scores",
path: "Update scores",
pathFormatted: "req_update-scores-221b9",
stats: {
    "name": "Update scores",
    "numberOfRequests": {
        "total": "100",
        "ok": "96",
        "ko": "4"
    },
    "minResponseTime": {
        "total": "11",
        "ok": "11",
        "ko": "2423"
    },
    "maxResponseTime": {
        "total": "9154",
        "ok": "9154",
        "ko": "3037"
    },
    "meanResponseTime": {
        "total": "2041",
        "ok": "2013",
        "ko": "2734"
    },
    "standardDeviation": {
        "total": "1786",
        "ok": "1816",
        "ko": "299"
    },
    "percentiles1": {
        "total": "1690",
        "ok": "1608",
        "ko": "2739"
    },
    "percentiles2": {
        "total": "2607",
        "ok": "2533",
        "ko": "3032"
    },
    "percentiles3": {
        "total": "5253",
        "ok": "5346",
        "ko": "3036"
    },
    "percentiles4": {
        "total": "8181",
        "ok": "8220",
        "ko": "3037"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 24,
    "percentage": 24
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 13,
    "percentage": 13
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 59,
    "percentage": 59
},
    "group4": {
    "name": "failed",
    "count": 4,
    "percentage": 4
},
    "meanNumberOfRequestsPerSecond": {
        "total": "2.222",
        "ok": "2.133",
        "ko": "0.089"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
